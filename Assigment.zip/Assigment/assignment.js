// ১. Variable কি ?


// স্টোরেজ অবস্থানের একটি নাম


// ২. Variable কিভাবে লিখতে হয় ?

var myName = "Jahangir";

console.log(myName);

// ৩. string type variable কি ও কি ভাবে লিখতে হয় ?


// Songka type variable ke string type variable bola hoy
var strType = "This is string type varibale";

console.log(strType);


// ৪. number type variable কি ও কি ভাবে লিখতে হয় ?


// 1 - 9 Number type varibale kei number type variable bola hoy..
var numType = 1051;

console.log(numType);

// ৫. Boolan type variable  কি ও কি ভাবে লিখতে হয় ?

var boolenType = (true);
var boolenType = (false);

console.log(boolenType);

// ৬. toUpperCase() & toLowerCase() এর ব্যাবহার কি ভাবে করতে হয় ? 

var upperCase =("is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.")

console.log(upperCase.toUpperCase())


var upperCase =("IS SIMPLY DUMMY TEXT OF THE PRINTING AND TYPESETTING INDUSTRY. LOREM IPSUM HAS BEEN THE INDUSTRY'S STANDARD DUMMY TEXT EVER SINCE THE 1500S, WHEN AN UNKN OWN PRINTER TOOK A GALLEY OF TYPE AND SCRAMBLED IT TO MAKE A TYPE SPECIMEN BOOK. IT HAS SURVIVED NOT ONLY FIVE CENTURIES, BUT ALSO THE LEAP INTO ELECTRON IC TYPESETTING, REMAINING ESSENTIALLY UNCHANGED. IT WAS POPULARISED IN THE 1960S WITH THE RELEASE OF LETRASET SHEETS CONTAINING LOREM IPSUM PASSAGES, AND MORE RECENTLY WITH DESKTOP PUBLISHING SOFTWARE LIKE ALDUS PAGEMAKER INCLUDING VERSIONS OF LOREM IPSUM.")

console.log(upperCase.toLocaleLowerCase())




// ৭. JavaScript এর মোট কয়টি অপারেটর আছে ও কি কি ?
// 10 ta operator ase

// Plus Operator
var num1 = (10);
var num2 = (40);

var totalPlus = (num1 + num2);

console.log(totalPlus);


// minus operator
var num3 = (100);
var num4 = (50);

var totalMinus = (num3 - num4);

console.log(totalMinus);



// gun operator
var gun1 = (100);
var gun2 = (5);

var totalGum = (gun1 * gun2)

console.log(totalGum);

//vag operator
var vag1 = (500)
var vag2 = (5);

var vagTotal = (vag1 / vag2)

console.log(vagTotal);





// ৮. Math.abs() এর ব্যাবহার লিখুন । 

var abstype2 = Math.abs(-60);

console.log(abstype2);

// ৯. Math.celi()  এর ব্যাবহার লিখুন । 

var mathCeli = Math.ceil(5.999);

console.log(mathCeli);


// ১০. Math.Floor() এর ব্যাবহার লিখুন । 

var mathFloor = Math.floor(5.9999999999);

console.log(mathFloor);

// ১১. Math.round() এর ব্যাবহার লিখুন ।

var mathRound = Math.round (0.999999);

console.log(mathRound);


// ১২. Math.random() এর ব্যাবহার লিখুন ।

var mathRandom = Math.random() * 100;
console.log(mathRandom);

 
// asignment.js - GitHub Link 
